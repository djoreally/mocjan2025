import MotorOilLookup from "./MotorOilLookup"

export default function MotorOilLookupPage() {
  return <MotorOilLookup />
}


const config = {
  analyticsKey: process.env.NEXT_PUBLIC_ANALYTICS_KEY || "YOUR_DEFAULT_WRITE_KEY",
  // Add other configuration variables as needed
}

export default config

